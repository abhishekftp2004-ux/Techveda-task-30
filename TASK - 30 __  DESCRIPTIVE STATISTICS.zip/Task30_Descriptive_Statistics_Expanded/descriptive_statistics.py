"""
TASK 30: DESCRIPTIVE STATISTICS
Tools: Python, Pandas, NumPy
Dataset: student_performance.csv
Run: python descriptive_statistics.py
"""
from pathlib import Path
import pandas as pd
import numpy as np

# 1. Load the dataset from the same folder as this script.
file_path = Path(__file__).with_name("student_performance.csv")
df = pd.read_csv(file_path)

# 2. Inspect the data before calculating statistics.
print("Shape:", df.shape)             # (rows, columns)
print("\nFirst five rows:\n", df.head())
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isna().sum())

# 3. Select the three numerical variables; Student_ID is an identifier,
#    so it should not be treated as a meaningful numeric measurement.
columns = ["Study_Hours", "Attendance_Percent", "Exam_Score"]
data = df[columns]

# 4. Quick statistical summary.
print("\nQUICK SUMMARY")
print(data.describe().round(2))

# 5. Calculate central tendency and dispersion.
results = pd.DataFrame({
    "Count": data.count(),
    "Mean": data.mean(),
    "Median": data.median(),
    # mode() can return multiple rows; iloc[0] selects the first mode.
    "Mode": data.mode().iloc[0],
    "Minimum": data.min(),
    "Maximum": data.max(),
    "Range": data.max() - data.min(),
    # ddof=1 uses the sample formula (n - 1).
    "Sample_Variance": data.var(ddof=1),
    "Sample_Std_Dev": data.std(ddof=1),
    "Q1_25%": data.quantile(0.25),
    "Q2_50%": data.quantile(0.50),
    "Q3_75%": data.quantile(0.75),
    "IQR": data.quantile(0.75) - data.quantile(0.25),
    "P10": data.quantile(0.10),
    "P90": data.quantile(0.90),
}).round(2)

print("\nDETAILED RESULTS")
print(results.to_string())

# 6. Compare mean and median for a simple, cautious distribution check.
print("\nMEAN VS MEDIAN")
for col in columns:
    mean_value = data[col].mean()
    median_value = data[col].median()
    if np.isclose(mean_value, median_value, atol=0.5):
        interpretation = "mean and median are close; centre is fairly balanced."
    elif mean_value > median_value:
        interpretation = "mean is higher; larger values may pull the mean upward."
    else:
        interpretation = "median is higher; smaller values may pull the mean downward."
    print(f"{col}: mean={mean_value:.2f}, median={median_value:.2f}; {interpretation}")

# 7. Export the table so it can be attached to a report or portfolio.
output_path = Path(__file__).with_name("descriptive_summary.csv")
results.to_csv(output_path, index_label="Variable")
print(f"\nSaved summary to: {output_path.name}")
